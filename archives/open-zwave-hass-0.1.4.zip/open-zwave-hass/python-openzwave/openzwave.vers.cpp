#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 3440;
char ozw_version_string[] = "1.4-3440-ge4e0c8d5-dirty";
